/*                                                                   */
/* 5770-XE1                                                          */
/* (C) Copyright IBM Corp. 2014,2014                                 */
/* All rights reserved.                                              */
/* US Government Users Restricted Rights -                           */
/* Use, duplication or disclosure restricted                         */
/* by GSA ADP Schedule Contract with IBM Corp.                       */
/*                                                                   */
/* Licensed Materials-Property of IBM                                */
/*                                                                   */


/*********************************************************************/
/*                                                                   */
/* Module:                                                           */
/*   cwbodbc.h                                                       */
/*                                                                   */
/* Purpose:                                                          */
/*   IBM i Access ODBC driver specific attributes and features.      */
/*                                                                   */
/* Usage Notes:                                                      */
/*                                                                   */
/*********************************************************************/
#ifndef CWB_ODBC_H
#define CWB_ODBC_H

// See the "Connection and statement attributes" topic in the IBM Knowledge Center for
// more information on usage of these attributes.
// For IBM i 7.2, the URL is https://www-01.ibm.com/support/knowledgecenter/ssw_ibm_i_72/rzaik/connstmtattr.htm?lang=en

// Connection and Statement Attributes
// ----------------------------------------
#define CWB_ATTR_DATA_COMPRESSION      2106 

// Connection Attributes
// These are legacy definitions
#define CWB_ATTR_NUM_RESULT_SETS       1014
#define CWB_ATTR_PRESERVE_CURSORS      1204

// These are within the IBM attribute range, reserved from Microsoft
#define CWB_ATTR_PACKAGE_LIBRARY       2100
#define CWB_ATTR_PACKAGE_NAME          2101
#define CWB_ATTR_SERVER_JOB_CCSID      2103
#define CWB_ATTR_DIVIDE_BY_ZERO        2104
#define CWB_ATTR_TRIM_CHAR_FIELDS      2109
#define CWB_ATTR_JOB_STRUCT            2110
#define CWB_ATTR_JOB_INFO              CWB_ATTR_JOB_STRUCT
#define CWB_ATTR_CATALOG_OPTIONS       2111
#define CWB_ATTR_EWLM_CORRELATOR       2116
#define CWB_ATTR_TXN_ISOLATION         2139
#define CWB_ATTR_XA_TXN_TIMEOUT        2140
#define CWB_ATTR_XA_LOCK_TIMEOUT       2141
#define CWB_ATTR_XA_RMID               2142
#define CWB_ATTR_XA_DLL_NAME           2143
#define CWB_ATTR_XML_DECLARATION       2145
#define CWB_ATTR_XML_STRIP_WHITESPACE  2146
#define CWB_ATTR_JOB_NAME              2148

// These match the DB2 Connect and DB2 LUW CLI values
#define CWB_ATTR_INFO_USERID           1281
#define CWB_ATTR_INFO_WRKSTNNAME       1282
#define CWB_ATTR_INFO_APPLNAME         1283
#define CWB_ATTR_INFO_ACCTSTR          1284
#define CWB_ATTR_INFO_PROGRAMID        2511
#define CWB_ATTR_CONCURRENT_ACCESS_RESOLUTION  2595


// Statement Attributes
// ----------------------------------------
#define CWB_ATTR_NUM_RESULT_SETS       1014
#define CWB_ATTR_POS_OF_SYNTAX_ERROR   2114


// Attribute options
// ----------------------------------------

// Options for CWB_ATTR_PRESERVE_CURSORS
#define CWB_CB_DELETE SQL_CB_DELETE
#define CWB_CB_PRESERVE SQL_CB_PRESERVE

// Options for CWB_ATTR_DIVIDE_BY_ZERO
#define CWB_DIVIDE_BY_ZERO_ERROR          0
#define CWB_DIVIDE_BY_ZERO_NULL           1

// Options for CWB_ATTR_DATA_COMPRESSION
#define CWB_COMPRESSION_ON                1
#define CWB_COMPRESSION_OFF               0

// Options for CWB_ATTR_TRIM_CHAR_FIELDS
#define CWB_PRESERVE_BLANKS               0
#define CWB_DELETE_BLANKS                 1

// Options for CWB_ATTR_CONCURRENT_ACCESS_RESOLUTION
#define CWB_CC_USE_SERVER_VALUE           0
#define CWB_CC_USE_CURRENTLY_COMMITTED    1
#define CWB_CC_WAIT_FOR_OUTCOME           2
#define CWB_CC_SKIP_LOCKED_DATA           3

// Options for CWB_ATTR_XML_DECLARATION
#define CWB_XML_NO_DECLARATION            0
#define CWB_XML_INCLUDE_BYTE_ORDER_MARK   1
#define CWB_XML_INCLUDE_DECLARATION       2
#define CWB_XML_ENCODING_IN_DECLARATION   4 // Only valid with CWB_XML_INCLUDE_DECLARATION
#define CWB_XML_BOM_AND_DECLARATION       ( CWB_XML_INCLUDE_BYTE_ORDER_MARK |CWB_XML_INCLUDE_DECLARATION )
#define CWB_XML_FULL_DECLARATION          ( CWB_XML_INCLUDE_DECLARATION | CWB_XML_ENCODING_IN_DECLARATION )
#define CWB_XML_BOM_AND_FULL_DECLARATION  ( CWB_XML_INCLUDE_BYTE_ORDER_MARK | CWB_XML_INCLUDE_DECLARATION | CWB_XML_ENCODING_IN_DECLARATION )

// Options for CWB_ATTR_XML_STRIP_WHITESPACE
#define CWB_XML_STRIP_WHITESPACE          0
#define CWB_XML_PRESERVE_WHITESPACE       1

// Indicator values to be used on SQLBindParameter/SQLPutData
#define CWB_UNASSIGNED                  (-7)

// Value for SQL_ATTR_TXN_ISOLATION / CWB_ATTR_TXN_ISOLATION
#define CWB_TXN_NO_COMMIT                 0L
#define CWB_TRANSACTION_NO_COMMIT         CWB_TXN_NO_COMMIT


#endif // CWB_ODBC_H
